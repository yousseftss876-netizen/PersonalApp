document.getElementById('injectBtn').addEventListener('click', async () => {
  const separator = document.getElementById('separator').value || ';';
  const statusDiv = document.getElementById('status');
  const injectBtn = document.getElementById('injectBtn');
  
  // Disable button and show loading
  injectBtn.disabled = true;
  injectBtn.textContent = '⏳ Injecting...';
  statusDiv.textContent = '⏳ Injecting copy button...';
  statusDiv.className = 'status info';
  
  // Get the current active tab
  const [tab] = await browser.tabs.query({ active: true, currentWindow: true });
  
  // Check if we're on the right page
  if (!tab.url.includes('95.216.72.6:90/tools/test/domains')) {
    statusDiv.textContent = '❌ Please navigate to the domains page first';
    statusDiv.className = 'status error';
    injectBtn.disabled = false;
    injectBtn.textContent = '📎 Inject Copy Button on Page';
    return;
  }
  
  try {
    // Execute script to inject the button
    const results = await browser.tabs.executeScript(tab.id, {
      code: `
        (function() {
          try {
            // Check if button already exists
            if (document.getElementById('custom-copy-rdns-btn')) {
              return { success: false, message: 'Copy button already exists on the page!' };
            }
            
            // Find the DKIM button
            const allButtons = Array.from(document.querySelectorAll('button, a, .btn, input[type="button"]'));
            let dkimBtn = allButtons.find(el => el.textContent.trim().toUpperCase() === 'DKIM');
            
            if (!dkimBtn) {
              return { success: false, message: 'DKIM button not found. Make sure the page is fully loaded.' };
            }
            
            // Create a container div for the copy button and separator input
            const container = document.createElement('div');
            container.style.display = 'inline-flex';
            container.style.alignItems = 'center';
            container.style.gap = '8px';
            container.style.marginLeft = '10px';
            
            // Create copy button
            const copyBtn = document.createElement('button');
            copyBtn.id = 'custom-copy-rdns-btn';
            copyBtn.className = dkimBtn.className;
            copyBtn.textContent = '📋 Copy';
            copyBtn.style.cssText = window.getComputedStyle(dkimBtn).cssText;
            copyBtn.style.cursor = 'pointer';
            copyBtn.style.display = 'inline-flex';
            copyBtn.style.alignItems = 'center';
            copyBtn.style.gap = '5px';
            
            // Create separator input group
            const separatorGroup = document.createElement('div');
            separatorGroup.style.display = 'inline-flex';
            separatorGroup.style.alignItems = 'center';
            separatorGroup.style.gap = '5px';
            separatorGroup.style.backgroundColor = '#f5f5f5';
            separatorGroup.style.padding = '4px 8px';
            separatorGroup.style.borderRadius = '4px';
            separatorGroup.style.border = '1px solid #ddd';
            
            const separatorLabel = document.createElement('span');
            separatorLabel.textContent = 'Separator:';
            separatorLabel.style.fontSize = '12px';
            separatorLabel.style.color = '#666';
            separatorLabel.style.fontWeight = 'normal';
            
            const separatorInput = document.createElement('input');
            separatorInput.type = 'text';
            separatorInput.value = '${separator}';
            separatorInput.style.width = '40px';
            separatorInput.style.padding = '4px';
            separatorInput.style.border = '1px solid #ccc';
            separatorInput.style.borderRadius = '3px';
            separatorInput.style.fontSize = '12px';
            separatorInput.style.textAlign = 'center';
            
            // Store separator reference
            copyBtn.setAttribute('data-separator', '${separator}');
            
            // Update separator when input changes
            separatorInput.addEventListener('change', function() {
              const newSeparator = this.value || ';';
              copyBtn.setAttribute('data-separator', newSeparator);
              copyBtn.style.backgroundColor = '#4CAF50';
              setTimeout(() => {
                copyBtn.style.backgroundColor = '';
              }, 300);
            });
            
            separatorInput.addEventListener('keyup', function(e) {
              if (e.key === 'Enter') {
                this.blur();
              }
            });
            
            separatorGroup.appendChild(separatorLabel);
            separatorGroup.appendChild(separatorInput);
            
            // Add click handler for copy button
            copyBtn.addEventListener('click', async function(e) {
              e.preventDefault();
              e.stopPropagation();
              
              const separator = this.getAttribute('data-separator') || ';';
              const originalText = this.textContent;
              const originalBg = this.style.backgroundColor;
              this.textContent = '⏳ Copying...';
              this.style.backgroundColor = '#ff9800';
              
              // Find RDNS table
              const tables = document.querySelectorAll('table');
              let targetTable = null;
              
              for (let table of tables) {
                const firstRow = table.querySelector('tr');
                if (!firstRow) continue;
                
                const headers = Array.from(firstRow.querySelectorAll('th, td'))
                                     .slice(0, 4)
                                     .map(h => h.textContent.trim().toLowerCase());
                
                if (headers[0]?.includes('server') && 
                    headers[1]?.includes('ip') && 
                    headers[2]?.includes('rdns') && 
                    headers[3]?.includes('status')) {
                  targetTable = table;
                  break;
                }
              }
              
              if (!targetTable) {
                alert('❌ RDNS table not found on this page');
                this.textContent = originalText;
                this.style.backgroundColor = originalBg;
                return;
              }
              
              // Extract data
              const rows = targetTable.querySelectorAll('tbody tr');
              let copiedData = [];
              
              for (let row of rows) {
                const cells = row.querySelectorAll('td');
                if (cells.length >= 4) {
                  let rowData = [];
                  for (let i = 0; i < 4; i++) {
                    rowData.push(cells[i].textContent.trim());
                  }
                  copiedData.push(rowData.join(separator));
                }
              }
              
              // If no tbody, try all rows
              if (copiedData.length === 0) {
                const allRows = targetTable.querySelectorAll('tr');
                for (let row of allRows) {
                  if (row.querySelector('th')) continue;
                  const cells = row.querySelectorAll('td');
                  if (cells.length >= 4) {
                    let rowData = [];
                    for (let i = 0; i < 4; i++) {
                      rowData.push(cells[i].textContent.trim());
                    }
                    copiedData.push(rowData.join(separator));
                  }
                }
              }
              
              const finalText = copiedData.join('\\n');
              
              if (!finalText) {
                alert('❌ No data rows found in the table');
                this.textContent = originalText;
                this.style.backgroundColor = originalBg;
                return;
              }
              
              // Copy to clipboard
              try {
                await navigator.clipboard.writeText(finalText);
                this.textContent = \`✅ \${copiedData.length} rows\`;
                this.style.backgroundColor = '#4CAF50';
                setTimeout(() => {
                  if (this.textContent !== '📋 Copy') {
                    this.textContent = '📋 Copy';
                    this.style.backgroundColor = originalBg;
                  }
                }, 2000);
              } catch (err) {
                // Fallback
                const textarea = document.createElement('textarea');
                textarea.value = finalText;
                textarea.style.position = 'fixed';
                textarea.style.left = '-9999px';
                document.body.appendChild(textarea);
                textarea.select();
                document.execCommand('copy');
                document.body.removeChild(textarea);
                this.textContent = \`✅ \${copiedData.length} rows\`;
                this.style.backgroundColor = '#4CAF50';
                setTimeout(() => {
                  if (this.textContent !== '📋 Copy') {
                    this.textContent = '📋 Copy';
                    this.style.backgroundColor = originalBg;
                  }
                }, 2000);
              }
            });
            
            container.appendChild(copyBtn);
            container.appendChild(separatorGroup);
            
            // Insert after DKIM button
            dkimBtn.parentNode.insertBefore(container, dkimBtn.nextSibling);
            
            // Add styles
            const style = document.createElement('style');
            style.id = 'custom-copy-btn-style';
            style.textContent = \`
              #custom-copy-rdns-btn:hover {
                opacity: 0.9;
                transform: translateY(-1px);
              }
              #custom-copy-rdns-btn:active {
                transform: translateY(0px);
              }
              .separator-input:hover {
                border-color: #4CAF50;
              }
            \`;
            document.head.appendChild(style);
            
            return { success: true, message: 'Copy button injected with separator input!' };
          } catch (err) {
            return { success: false, message: err.toString() };
          }
        })();
      `
    });
    
    const result = results[0];
    
    if (result && result.success) {
      statusDiv.textContent = `✅ ${result.message}`;
      statusDiv.className = 'status success';
    } else {
      statusDiv.textContent = `❌ ${result ? result.message : 'Unknown error'}`;
      statusDiv.className = 'status error';
    }
  } catch (error) {
    console.error('Error:', error);
    statusDiv.textContent = '❌ Could not access the page. Reload the page and try again.';
    statusDiv.className = 'status error';
  } finally {
    injectBtn.disabled = false;
    injectBtn.textContent = '📎 Inject Copy Button on Page';
    
    // Clear status after 3 seconds
    setTimeout(() => {
      if (statusDiv.className !== 'status') {
        statusDiv.className = 'status';
        statusDiv.textContent = '';
      }
    }, 3000);
  }
});

// Remove button functionality
document.getElementById('removeBtn').addEventListener('click', async () => {
  const statusDiv = document.getElementById('status');
  const removeBtn = document.getElementById('removeBtn');
  
  removeBtn.disabled = true;
  removeBtn.textContent = '⏳ Removing...';
  
  const [tab] = await browser.tabs.query({ active: true, currentWindow: true });
  
  if (!tab.url.includes('95.216.72.6:90/tools/test/domains')) {
    statusDiv.textContent = '❌ Please navigate to the domains page first';
    statusDiv.className = 'status error';
    removeBtn.disabled = false;
    removeBtn.textContent = '🗑️ Remove Copy Button';
    return;
  }
  
  try {
    const results = await browser.tabs.executeScript(tab.id, {
      code: `
        (function() {
          const container = document.querySelector('#custom-copy-rdns-btn')?.parentNode;
          const style = document.getElementById('custom-copy-btn-style');
          
          if (container && container.parentNode) {
            container.remove();
          }
          if (style) {
            style.remove();
          }
          
          return { success: true, message: container ? 'Copy button removed!' : 'No copy button found to remove.' };
        })();
      `
    });
    
    const result = results[0];
    statusDiv.textContent = `✅ ${result.message}`;
    statusDiv.className = 'status success';
  } catch (error) {
    statusDiv.textContent = '❌ Could not remove button';
    statusDiv.className = 'status error';
  } finally {
    removeBtn.disabled = false;
    removeBtn.textContent = '🗑️ Remove Copy Button';
    
    setTimeout(() => {
      if (statusDiv.className !== 'status') {
        statusDiv.className = 'status';
        statusDiv.textContent = '';
      }
    }, 2000);
  }
});